from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import os
from datetime import datetime
import json
import openai
from typing import List, Optional, Dict
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Import authentication
try:
    from auth.msal_validator import get_current_user, optional_auth, get_user_info
    MSAL_ENABLED = True
    logger.info("MSAL authentication enabled")
except ImportError as e:
    logger.warning(f"MSAL authentication not available: {e}")
    MSAL_ENABLED = False
    
    # Fallback functions when MSAL is not available
    async def get_current_user():
        return {"preferred_username": "dev@example.com", "name": "Development User"}
    
    async def optional_auth():
        return None
    
    def get_user_info(user_claims):
        return {"username": "dev@example.com", "name": "Development User"}

app = FastAPI(
    title="SageInsure AI API", 
    version="3.0.0",
    description="MSAL-authenticated AI-powered insurance assistant"
)

# CORS middleware with environment-based origins
allowed_origins = os.getenv('CORS_ORIGINS', 'http://localhost:3000,http://localhost:3001').split(',')
app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Azure AI Foundry Configuration
openai.api_type = "azure"
openai.api_base = os.getenv("AZURE_OPENAI_ENDPOINT", "https://parvinddutta-9607_ai.openai.azure.com/")
openai.api_key = os.getenv("AZURE_OPENAI_API_KEY", "172068a0b5a348efa948c8339cca0329")
openai.api_version = "2024-02-15-preview"

# Specialist system prompts
SPECIALIST_PROMPTS = {
    "CLAIMS_MANAGER": "You are a Claims Manager AI for SageInsure. Help customers file claims, check status, and provide claims guidance. Be professional and ask for specific details.",
    "POLICY_ASSISTANT": "You are a Policy Assistant AI for SageInsure. Help customers understand policies, coverage, premiums, and policy changes. Explain terms clearly.",
    "MARINE_SPECIALIST": "You are a Marine Insurance Specialist AI for SageInsure. Specialize in vessel insurance, cargo protection, and maritime risks.",
    "CYBER_SPECIALIST": "You are a Cyber Insurance Specialist AI for SageInsure. Help with cyber security insurance, data breach coverage, and cyber risk assessment.",
    "FNOL_PROCESSOR": "You are a First Notice of Loss (FNOL) Processor AI for SageInsure. Help customers report incidents and guide through initial reporting.",
    "UNDERWRITER": "You are an Underwriting Specialist AI for SageInsure. Help with risk assessment, policy pricing, and underwriting decisions.",
    "RESEARCH_ASSISTANT": "You are a Research Assistant AI for SageInsure. Help with insurance market research, data analysis, and industry trends.",
}

class ChatRequest(BaseModel):
    text: str
    conversationId: str = "session"
    specialist: str = "GENERAL"
    context: List[dict] = []

class ChatResponse(BaseModel):
    response: str
    agent: str
    specialist: str
    confidence: float
    status: str
    conversationId: str
    timestamp: str
    user: Optional[str] = None

@app.get("/")
async def health_check():
    return {
        "status": "SageInsure AI API Running",
        "version": "3.0.0",
        "timestamp": datetime.now().isoformat(),
        "authentication": "MSAL Enabled" if MSAL_ENABLED else "Development Mode",
        "azure_ai": "Foundry Integrated",
        "model": "gpt-4o",
        "platform": "Azure AI Foundry",
        "project": "maplesage-openai-project"
    }

@app.get("/auth/status")
async def auth_status(user: Dict = Depends(get_current_user)):
    """Get current user authentication status"""
    user_info = get_user_info(user)
    return {
        "authenticated": True,
        "user": {
            "name": user_info.get('name'),
            "email": user_info.get('email'),
            "username": user_info.get('username'),
            "tenant": user.get('tid') if MSAL_ENABLED else 'development'
        },
        "timestamp": datetime.now().isoformat(),
        "msal_enabled": MSAL_ENABLED
    }

def get_fallback_response(specialist: str, text: str) -> str:
    """Fallback responses when Azure OpenAI is unavailable"""
    if "claim" in text.lower():
        return "I can help you with your claim. Please provide details about the incident, date, and type of claim you'd like to file."
    elif "policy" in text.lower():
        return "I can assist with policy questions. What would you like to know about your coverage, premiums, or policy details?"
    elif "marine" in text.lower():
        return "I specialize in marine insurance. How can I help with vessel coverage, cargo protection, or maritime risks?"
    elif "cyber" in text.lower():
        return "I can help with cyber insurance questions. Are you looking for coverage information or reporting a security incident?"
    else:
        return f"I'm your {specialist.replace('_', ' ').title()} assistant. How can I help you today?"

@app.post("/chat")
async def chat_endpoint(
    request: ChatRequest, 
    user: Optional[Dict] = Depends(optional_auth)
):
    """AI-powered chat endpoint with optional authentication"""
    
    try:
        # Map frontend specialist names
        specialist_mapping = {
            "CLAIMS_CHAT": "CLAIMS_MANAGER",
            "MARINE_INSURANCE": "MARINE_SPECIALIST",
            "CYBER_INSURANCE": "CYBER_SPECIALIST",
            "UNDERWRITING": "UNDERWRITER",
        }
        
        mapped_specialist = specialist_mapping.get(request.specialist, request.specialist)
        
        # Get specialist system prompt
        system_prompt = SPECIALIST_PROMPTS.get(
            mapped_specialist, 
            "You are a helpful insurance AI assistant for SageInsure. Help customers with their insurance needs."
        )
        
        # Build conversation messages
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": request.text}
        ]
        
        # Add context if provided
        if request.context:
            for ctx in request.context[-3:]:  # Last 3 messages for context
                if ctx.get("role") and ctx.get("content"):
                    messages.insert(-1, {"role": ctx["role"], "content": ctx["content"]})
        
        # Call Azure AI Foundry OpenAI
        response = openai.ChatCompletion.create(
            engine="gpt-4o",  # Azure AI Foundry deployment name
            messages=messages,
            temperature=0.7,
            max_tokens=800,
            top_p=0.9
        )
        
        ai_response = response.choices[0].message.content
        
        # Log user activity if authenticated
        if user and MSAL_ENABLED:
            user_info = get_user_info(user)
            logger.info(f"Chat request from user: {user_info.get('username', 'unknown')} - Specialist: {request.specialist}")
        
        return ChatResponse(
            response=ai_response,
            agent=f"SageInsure AI {request.specialist.replace('_', ' ').title()}",
            specialist=request.specialist,
            confidence=0.95,
            status="success",
            conversationId=request.conversationId,
            timestamp=datetime.now().isoformat(),
            user=user_info.get('username') if user and MSAL_ENABLED else None
        )
        
    except Exception as e:
        print(f"Azure OpenAI Error: {e}")
        
        # Fallback to specialist-specific response
        fallback_response = get_fallback_response(request.specialist, request.text)
        
        return ChatResponse(
            response=fallback_response,
            agent=f"SageInsure {request.specialist.replace('_', ' ').title()}",
            specialist=request.specialist,
            confidence=0.7,
            status="fallback",
            conversationId=request.conversationId,
            timestamp=datetime.now().isoformat(),
            user=get_user_info(user).get('username') if user and MSAL_ENABLED else None
        )

# Keep original functions as fallback (remove the detailed implementations to save space)
def generate_claims_response(text: str) -> str:
    text_lower = text.lower()
    
    if any(word in text_lower for word in ["file", "submit", "report"]):
        return """I'll help you file a claim right away! Here's what I need:

🔍 **Claim Information:**
• Type of incident (auto, property, health, etc.)
• Date and time it occurred
• Location of the incident
• Description of what happened

📋 **Required Documents:**
• Photos of any damage
• Police report (if applicable)
• Medical records (for injury claims)
• Receipts for expenses

📞 **Next Steps:**
1. I'll create your claim number
2. Assign an adjuster within 24 hours
3. Schedule inspection if needed
4. Keep you updated throughout the process

What type of claim would you like to file?"""
    
    elif any(word in text_lower for word in ["status", "track", "update"]):
        return """I can help you track your claim status. Here's what I can check:

📊 **Claim Status Options:**
• **Submitted** - We've received your claim
• **Under Review** - Adjuster is investigating
• **Pending** - Waiting for additional information
• **Approved** - Claim approved for payment
• **Settled** - Payment has been processed

🔍 **To check your status, I need:**
• Your claim number, OR
• Policy number and incident date

What's your claim number or policy information?"""
    
    return """👋 Hello! I'm your Claims Manager. I can help you with:

🚗 **Auto Claims** - Accidents, theft, vandalism
🏠 **Property Claims** - Fire, water damage, storms
🏥 **Health Claims** - Medical treatments, prescriptions
💼 **Business Claims** - Commercial liability, property
⚓ **Marine Claims** - Vessel damage, cargo loss

**Quick Actions:**
• File a new claim
• Check claim status
• Upload documents
• Schedule adjuster visit
• Get repair estimates

What can I help you with today?"""

def generate_policy_response(text: str) -> str:
    text_lower = text.lower()
    
    if any(word in text_lower for word in ["coverage", "covered", "cover"]):
        return """Let me explain your coverage options:

📋 **Standard Coverage Types:**

🚗 **Auto Insurance:**
• Liability (required by law)
• Collision (vehicle damage)
• Comprehensive (theft, weather, vandalism)
• Medical payments
• Uninsured/underinsured motorist

🏠 **Home Insurance:**
• Dwelling coverage (structure)
• Personal property
• Liability protection
• Additional living expenses
• Medical payments to others

💡 **To check your specific coverage:**
• Provide your policy number
• Tell me what situation you're asking about
• I'll explain exactly what's covered

What type of coverage question do you have?"""
    
    elif any(word in text_lower for word in ["premium", "cost", "price", "payment"]):
        return """I can help you understand your premium and payment options:

💰 **Premium Factors:**
• Coverage limits and deductibles
• Your location and risk factors
• Claims history and credit score
• Vehicle/property characteristics
• Available discounts

💳 **Payment Options:**
• Monthly automatic payments
• Quarterly or semi-annual payments
• Annual payment (often includes discount)
• Online payment portal
• Phone or mail payments

🎯 **Ways to Save:**
• Bundle multiple policies
• Increase deductibles
• Maintain good driving record
• Install safety devices
• Take defensive driving courses

Would you like a quote or help with payment options?"""
    
    return """📄 Hi! I'm your Policy Assistant. I can help with:

**Policy Services:**
• Coverage explanations and limits
• Premium calculations and discounts
• Policy updates and changes
• Renewal information
• Adding or removing coverage

**Common Questions:**
• What's covered under my policy?
• How can I lower my premium?
• When is my renewal date?
• How do I add a driver or vehicle?
• What discounts am I eligible for?

**Quick Actions:**
• Get policy documents
• Update contact information
• Request coverage changes
• Set up automatic payments

What policy question can I answer for you?"""

def generate_marine_response(text: str) -> str:
    return """⚓ Welcome to Marine Insurance! I specialize in maritime coverage:

🚢 **Vessel Insurance:**
• Hull and machinery coverage
• Protection & Indemnity (P&I)
• Crew liability and medical
• Marina and mooring coverage
• Salvage and wreck removal

📦 **Cargo Insurance:**
• Import/export shipments
• Inland transit coverage
• Warehouse-to-warehouse protection
• International trade coverage
• Temperature-sensitive cargo

🌊 **Marine Perils Covered:**
• Storm and weather damage
• Collision and grounding
• Fire and explosion
• Piracy and theft
• General average contributions
• Sue and labor expenses

🎯 **Specialized Services:**
• Marine surveys and inspections
• Loss prevention consulting
• Claims handling worldwide
• 24/7 emergency response

Whether you're a commercial operator, cargo shipper, or recreational boater, I can help you navigate marine insurance. What type of marine coverage do you need?"""

def generate_cyber_response(text: str) -> str:
    return """🔒 Cyber Insurance Specialist here! I protect against digital threats:

💻 **Cyber Coverage Areas:**
• Data breach response and notification
• Ransomware and malware attacks
• Business interruption from cyber events
• Cyber extortion and social engineering
• Network security liability
• Privacy liability claims

🛡️ **Risk Assessment Services:**
• Cybersecurity vulnerability scans
• Employee training programs
• Incident response planning
• Compliance consulting (GDPR, HIPAA, PCI)
• Security best practices guidance

⚡ **Immediate Incident Response:**
• 24/7 cyber incident hotline
• Forensic investigation coordination
• Legal and regulatory compliance
• Public relations and crisis management
• Customer notification services

🎯 **Industries We Serve:**
• Healthcare and medical practices
• Financial services
• Retail and e-commerce
• Manufacturing
• Professional services
• Small to enterprise businesses

Are you looking for cyber coverage, dealing with an incident, or need a risk assessment?"""

def generate_fnol_response(text: str) -> str:
    return """📞 First Notice of Loss (FNOL) - I'm here for immediate incident reporting!

🚨 **Report Your Loss Now:**

**Step 1: Safety First**
• Ensure everyone is safe and secure
• Call 911 if there are injuries
• Move to a safe location if possible

**Step 2: Document Everything**
• Take photos of damage/scene
• Get contact info from witnesses
• Note weather conditions
• Record time and location details

**Step 3: Information I Need**
• Date, time, and location of incident
• Description of what happened
• Parties involved and their information
• Police report number (if applicable)
• Estimated damages or injuries

**Step 4: Immediate Actions**
• I'll assign your claim number instantly
• Connect you with an adjuster within 24 hours
• Arrange emergency services if needed
• Provide claim status updates

🎯 **Types of Incidents:**
• Auto accidents and collisions
• Property damage (fire, storm, theft)
• Workplace injuries
• Liability incidents
• Marine casualties

Ready to report your incident? Let's start with what happened and when."""

def generate_underwriting_response(text: str) -> str:
    return """📊 Underwriting Specialist - I evaluate risks and determine coverage:

🔍 **Risk Assessment Process:**
• Application review and verification
• Financial analysis and credit evaluation
• Loss history and claims analysis
• Property inspection coordination
• Industry and geographic risk factors

📈 **Underwriting Services:**
• New business evaluation
• Renewal underwriting
• Coverage modifications
• Risk improvement recommendations
• Premium calculations and rating

💼 **Specialized Lines:**
• Commercial general liability
• Professional liability
• Directors & officers coverage
• Cyber liability
• International coverage
• High-value personal lines

🎯 **Risk Management:**
• Loss control services
• Safety program development
• Claims prevention strategies
• Industry best practices
• Regulatory compliance guidance

**Underwriting Factors:**
• Business operations and exposures
• Safety records and procedures
• Financial stability
• Management experience
• Geographic considerations

What type of coverage are you looking to underwrite, or do you need help with risk assessment?"""

def generate_research_response(text: str) -> str:
    return """🔬 Research Assistant - Providing data-driven insurance insights:

📊 **Market Research & Analysis:**
• Industry trends and forecasting
• Competitive intelligence
• Regulatory impact analysis
• Emerging risk identification
• Market opportunity assessment

📈 **Data Analytics Services:**
• Claims pattern analysis
• Loss ratio calculations
• Pricing model development
• Risk correlation studies
• Predictive modeling

🎯 **Strategic Research:**
• Product development insights
• Market expansion opportunities
• Customer behavior analysis
• Technology impact assessment
• Demographic trend analysis

💡 **Research Capabilities:**
• Statistical analysis and modeling
• Survey design and execution
• Focus group coordination
• Literature reviews
• Regulatory research
• Economic impact studies

**Recent Research Areas:**
• Climate change impact on insurance
• Autonomous vehicle implications
• Cyber risk evolution
• Pandemic business interruption
• ESG factors in underwriting

What research question or analysis can I help you with today?"""

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)